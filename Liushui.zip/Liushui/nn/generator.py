import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import time

filePath = 'system type rules.xlsx'

process_path = '../output/yikongall2.xlsx'


def reverse_map(rules):
    rev_map = {}
    for key, val in rules.items():
        for v in val:
            rev_map[v] = key
    return rev_map

def get_rules(filePath):
    df = pd.read_excel(filePath, sheet_name=1, header=1)
    ins = list(range(0, 8)) + list(range(23, 28)) + list(range(32, 35))
    data_df = df.iloc[:, [2, 3]]
    types = data_df['系统分类'].values
    rules = {}
    in_or_out = {}
    print(data_df.dtypes)
    data_df['交易类型/摘要'] = data_df['交易类型/摘要'].astype(str)
    for i in data_df.index:
        key = data_df.loc[i].values[0]
        if i in ins:
            in_or_out[key] = 1
        else:
            in_or_out[key] = 0
        val = data_df.loc[i].values[1].split('/')
        rules[key] = val
    print(rules)
    print(in_or_out)

    in_map, out_map = {}, {}
    for key, val in rules.items():
        if in_or_out[key] == 1:
            for v in val:
                in_map[v] = key
        else:
            for v in val:
                out_map[v] = key

    return in_map, out_map, in_or_out


def process_file(process_path, in_map, out_map, in_or_out):
    df = pd.read_excel(process_path)
    for i in df.index:
        abstra = df.loc[i].values[9]
        inval = df.loc[i].values[10]
        outval = df.loc[i].values[11]
        try:
            if float(inval) > 0:
                for key in in_map.keys():
                    if key in str(abstra):
                        # print(in_map[key])
                        df['系统分类'].loc[i] = in_map[key]
        except Exception as e:
            print(e)
        try:
            if float(outval) > 0:
                for key in out_map.keys():
                    if key in str(abstra):
                        # print(out_map[key])
                        df['系统分类'].loc[i] = out_map[key]
        except Exception as e:
            print(e)
    writer = pd.ExcelWriter('output.xlsx')
    df.to_excel(writer, sheet_name='Sheet1')
    writer.save()
    print('DataFrame is written successfully to the Excel File.')

if __name__ == '__main__':
    start_time = time.time()
    in_map, out_map, in_or_out = get_rules(filePath)
    try:
        del in_map['']
        del in_map[' ']
        del in_map['nan']
        del out_map['']
        del out_map[' ']
        del out_map['nan']
    except:
        pass
    print(out_map.keys())
    print(in_map.keys())
    # process_file(process_path, in_map, out_map, in_or_out)
    # print("--- %s seconds ---" % (time.time() - start_time))
